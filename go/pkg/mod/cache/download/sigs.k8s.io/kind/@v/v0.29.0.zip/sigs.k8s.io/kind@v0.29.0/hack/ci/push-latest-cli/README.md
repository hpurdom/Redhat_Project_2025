This tooling is used for our automated builds.

These are meant to be consumed *only* by The Kubernetes Project's CI for 
testing Kubernetes.

These builds are currently not supported for other purposes.

See github.com/kubernetes/test-infra for the automation that invokes these.