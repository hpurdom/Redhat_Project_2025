---
name: Documentation Request
about: Suggest what should be documented in kind
labels: kind/documentation

---
<!-- Please only use this template for submitting documentation requests -->

**What would you like to be documented**:

**Why is this needed**:
