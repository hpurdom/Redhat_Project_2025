This directory contains glue used to test the kind repo in CI.

We don't recommend reusing anything from these scripts, and intend to replace
them at some point.